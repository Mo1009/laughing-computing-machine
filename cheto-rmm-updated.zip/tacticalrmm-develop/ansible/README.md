### tacticalrmm ansible WIP

ansible role to setup a Debian 11 VM for tacticalrmm local development