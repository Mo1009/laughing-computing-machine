# Security Policy

## Supported Versions

[Latest](https://github.com/amidaware/tacticalrmm/releases/latest) release

## Reporting a Vulnerability

https://docs.tacticalrmm.com/security
