from django.apps import AppConfig


class AutotasksConfig(AppConfig):
    name = "autotasks"
