from model_bakery.recipe import Recipe

task = Recipe(
    "autotasks.AutomatedTask",
)
