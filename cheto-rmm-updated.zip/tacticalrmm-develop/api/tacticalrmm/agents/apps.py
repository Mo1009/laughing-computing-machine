from django.apps import AppConfig


class AgentsConfig(AppConfig):
    name = "agents"
