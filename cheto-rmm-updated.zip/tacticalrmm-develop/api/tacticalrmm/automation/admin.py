from django.contrib import admin

from .models import Policy

admin.site.register(Policy)
